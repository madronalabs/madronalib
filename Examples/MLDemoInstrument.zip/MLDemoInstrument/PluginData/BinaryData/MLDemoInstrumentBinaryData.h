/* (Auto-generated binary data file). */

#ifndef BINARY_MLDEMOINSTRUMENTBINARYDATA_H
#define BINARY_MLDEMOINSTRUMENTBINARYDATA_H

namespace MLDemoInstrumentBinaryData
{
    extern const char*  arrowleft_svg;
    const int           arrowleft_svgSize = 687;

    extern const char*  arrowright_svg;
    const int           arrowright_svgSize = 688;

    extern const char*  masthead_svg;
    const int           masthead_svgSize = 32612;

    extern const char*  mlexample_xml;
    const int           mlexample_xmlSize = 11478;

};

#endif
