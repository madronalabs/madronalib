type "./make_data" here to run the BinaryBuilder executable 
on the contents of the BinarySrc folder, creating the output
source files in the BinaryData folder. The BinaryBuilder is
part of the JUCE distribution.
